# Alwas search 
Firefox extension for find words in webpage anytime.   
It is like a persistent CTRL+F for all tabs.
    
Put words or a sentence in the text area and click on the search button.    
The module find for you all occurrences on your active tab and on your future web pages.    

You will receive notification on your page when occurrences are found.

## Warning
This is a beta test. 

### Used technologies 
* Javascript

